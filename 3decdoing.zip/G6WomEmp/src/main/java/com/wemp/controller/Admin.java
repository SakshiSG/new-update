package com.wemp.controller;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.wemp.dao.AdminDao;


import com.wemp.model.TraineeModel;

@Controller
public class Admin {
	
@Autowired
AdminDao edao;

@RequestMapping(value ="/statusUpdation", method=RequestMethod.GET)
public ModelAndView updateStatus(HttpServletRequest request)
{
	
	long regid=Long.parseLong(request.getParameter("memid"));
	String statuss=request.getParameter("stat");
	System.out.println("before fetching form database");
	System.out.println(statuss);
	System.out.println(regid);
	TraineeModel mo =new TraineeModel();
	   mo.setRid(regid);
	   mo.setStatus(statuss);
	System.out.println("after setting values");
	System.out.println(mo.getRid());
	System.out.println(mo.getStatus());
	int num=edao.updateTrainee(mo);
	if(num>0)
	{
		System.out.println("successful update");
		 return new ModelAndView("confirm");
	}
	else
	{
		System.out.println("unsuccessful update");
		 return new ModelAndView();
	}
	
  
}

@RequestMapping("/adminverify")
public ModelAndView adminLogin(HttpServletRequest request)
{
	String admname = "Admin";
	String password="Admin123";
	String uname =request.getParameter("username");
	String pass=request.getParameter("password");
	if(Objects.equals(uname, admname) & Objects.equals(password, pass))
    {
		return new ModelAndView("gettraineeform");
	}
	else
	{
		return new ModelAndView();
	}

}


}
