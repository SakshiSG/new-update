package com.wemp.controller;

public class NgoController {

}
