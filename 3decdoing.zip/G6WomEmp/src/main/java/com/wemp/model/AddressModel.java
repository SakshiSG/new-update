package com.wemp.model;
/**
 * 
 * @author vshadmin
 * @return returns rid. 
 *
 */
public class AddressModel {
	private String city;
	private String State;
	private long pin;
	private long rid;
	public long getRid() {
		return rid;
	}
/*
 * @param rid as parameter.
 * @return rid to return.
 */
	public void setRid(long rid) {
		this.rid = rid;
	}
	public String getCity() {
		return city;
	}
	/*
	 * @param city as a parameter.
	 * @return city to return.
	 */
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public long getPin() {
		return pin;
	}
	/*
	 * @param pin as parameter.
	 * @return pin to return.
	 */
	public void setPin(long pin) {
		this.pin = pin;
	}

}
