package com.wemp.model;

public class CourseInfo {
	private long gpt_rid;
	private String gpt_firstname;
	private String gpt_middlename;
	private String gpt_lastname;
	private String gpt_dob;
	private String gpt_email;
	private String gpt_uname;
	private String gpt_password;
	private long gpt_aadhar;
	private long gpt_phone ;
	private String gpt_status;
	private String gpt_certificate;
	
	public String getGpt_certificate() {
		return gpt_certificate;
	}
	public void setGpt_certificate(String gpt_certificate) {
		this.gpt_certificate = gpt_certificate;
	}
	public void setGpt_status(String gpt_status) {
		this.gpt_status = gpt_status;
	}
	private String gtc_course_name;
	private String gtc_ngo_name;
	private int  gtc_duration;
	public long getGpt_rid() {
		return gpt_rid;
	}
	public void setGpt_rid(long gpt_rid) {
		this.gpt_rid = gpt_rid;
	}
	public String getGpt_firstname() {
		return gpt_firstname;
	}
	public void setGpt_firstname(String gpt_firstname) {
		this.gpt_firstname = gpt_firstname;
	}
	public String getGpt_middlename() {
		return gpt_middlename;
	}
	public void setGpt_middlename(String gpt_middlename) {
		this.gpt_middlename = gpt_middlename;
	}
	public String getGpt_lastname() {
		return gpt_lastname;
	}
	public void setGpt_lastname(String gpt_lastname) {
		this.gpt_lastname = gpt_lastname;
	}
	public String getGpt_dob() {
		return gpt_dob;
	}
	public void setGpt_dob(String gpt_dob) {
		this.gpt_dob = gpt_dob;
	}
	public String getGpt_email() {
		return gpt_email;
	}
	public void setGpt_email(String gpt_email) {
		this.gpt_email = gpt_email;
	}
	public String getGpt_uname() {
		return gpt_uname;
	}
	public void setGpt_uname(String gpt_uname) {
		this.gpt_uname = gpt_uname;
	}
	public String getGpt_password() {
		return gpt_password;
	}
	public void setGpt_password(String gpt_password) {
		this.gpt_password = gpt_password;
	}
	public long getGpt_aadhar() {
		return gpt_aadhar;
	}
	public void setGpt_aadhar(long gpt_aadhar) {
		this.gpt_aadhar = gpt_aadhar;
	}
	public long getGpt_phone() {
		return gpt_phone;
	}
	public void setGpt_phone(long gpt_phone) {
		this.gpt_phone = gpt_phone;
	}
	public String getGpt_status() {
		return gpt_status;
	}
	public void setGtp_status(String gpt_status) {
		this.gpt_status = gpt_status;
	}
	public String getGtc_course_name() {
		return gtc_course_name;
	}
	public void setGtc_course_name(String gtc_course_name) {
		this.gtc_course_name = gtc_course_name;
	}
	public String getGtc_ngo_name() {
		return gtc_ngo_name;
	}
	public void setGtc_ngo_name(String gtc_ngo_name) {
		this.gtc_ngo_name = gtc_ngo_name;
	}
	public int getGtc_duration() {
		return gtc_duration;
	}
	public void setGtc_duration(int gtc_duration) {
		this.gtc_duration = gtc_duration;
	}
	
	

}
