package com.wemp.service;

public class TraineeService {
	 String s=" ";
	public String encripPass(String strpass)
	{
		char[] ch=strpass.toCharArray();  
		for(int i=0;i<ch.length;i++){ 
			int num=(int)ch[i];
			num=num+3;
		   char	c=(char)num;
		    s=s+Character.toString(c);
		 
		} 
		System.out.print(s);
		return s;
		
	}
	public String getEncppass(String encpass)
	{
		char[] ch=encpass.toCharArray();  
		for(int i=0;i<ch.length;i++){ 
			int num=(int)ch[i];
			num=num+3;
		   char	c=(char)num;
		    s=s+Character.toString(c);
		 
		} 
		//System.out.print(s);
		return s;
		
		
	}
	
	public String getdecPassword(String epass)
	{
		char[] ch=epass.toCharArray();  
		for(int i=0;i<ch.length;i++){ 
			int num=(int)ch[i];
			num=num-3;
		   char	c=(char)num;
		    s=s+Character.toString(c);
		 
		} 
		//System.out.print(s);
		return s;
		
		
	}


}
